initTable();
function initTable() {
    var stockCode = localStorage.stockCode;
    var table = document.getElementById("stocklist");
    if(!stockCode) {
        table.style.visibility="hidden";
    } else {
        var stock = JSON.parse(stockCode);
        var content = "<tr ><th>股票代码</th><th id='showstockname'>股票名称&nbsp;?</th></tr>";
        var temp = "";
        for (var index in stock) {
            var obj = stock[index];
            temp += '<tr><td>'+obj["stockcode"]+'</td><td>'+obj["stockname"]+'</td></tr>'
        }
        content += temp;
        table.innerHTML = content;
        table.style.visibility="inline";
    }
}
document.getElementById('add').onclick = function(){
    //localStorage.stockCode = document.getElementById('stockCode').value;
    var stockcode= document.getElementById('stockCode').value;
    var content = {};
    content["stockcode"] = stockcode;
    content["stockname"] = "";
    var stockCode = localStorage.stockCode;
    if (!stockCode) {
        stockCode = [];
    } else {
        stockCode = JSON.parse(stockCode);
    }
    if (!isExisted(stockcode, stockCode)) {
        stockCode.push(content);
        localStorage.stockCode = JSON.stringify(stockCode);
        initTable();
    }
};
function isExisted(stockcode, stock) {
    for (var index in stock) {
        var obj = stock[index];
        if (obj["stockcode"] == stockcode) {
            return true;
        }
    }
    return false;
}
document.getElementById('clear').onclick = function(){
    localStorage.clear();
};
document.getElementById('showstockname').onclick = function (event) {
    var oEvent= event;
    var showtip = document.getElementById("showtips");
    showtip.style.display="block";
    var scrollTop=document.documentElement.scrollTop||document.body.scrollTop;
    var scrollLeft=document.documentElement.scrollLeft||document.body.scrollLeft;
    showtip.style.left=oEvent.clientX+scrollLeft+'px';
    showtip.style.top=oEvent.clientY+scrollTop+'px';
    setTimeout(function () {
        showtip.style.display="none";
    }, 3000);
};
