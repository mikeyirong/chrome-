function httpRequest(url, callback){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            callback(xhr.responseText);
        }
    };
    xhr.send();
}

function websocketRequest(url, callback) {
    var ws = new WebSocket(url);
    ws.open = function () {
        console.log("open")
    };
    ws.onmessage = function (event) {
        var data = event.data.split("\n");
        for (var index in data) {
            if (data[index]) {
                callback(data[index])
            }
        }
    };
    ws.onerror = function (event) {
        alert(event)
    }
}
function initData(stockCodeList) {
    var websocketUrl = "ws://hq.sinajs.cn/wskt?list=";
    var stockCode = "";
    for (var index in stockCodeList) {
        stockCode += stockCodeList[index]+",";
    }
    stockCode = stockCode.substring(0, stockCode.length-1);
    websocketRequest(websocketUrl+stockCode, updateData);
}
function updateData(result){
    /*result = JSON.parse(result);
    var obj=eval(result);*/
    var resultJSON = parseResult(result);
    var currentStockCode = resultJSON["stockCode"];
    document.getElementById(currentStockCode).innerHTML=dealOneline(resultJSON);
}
// 初始化表格
function initTable(stockCodeList) {
    var table = '<table><tr><th>股票代码</th><th>名称</th><th>涨幅</th><th>现价</th><th>涨跌</th></tr>';
    for (var index in stockCodeList) {
        table += '<tr id="'+stockCodeList[index]+'"></tr>';
    }
    table += '</table>';
    document.getElementById('stock').innerHTML = table;
    initData(stockCodeList);

}
// 处理一行数据
function dealOneline(resultJSON) {
    var line = "";
    line += '<td style="font-weight: bold;">'+resultJSON["stockCode"]+'</td>';//股票代码
    line += '<td style="font-weight: bold;">'+resultJSON["stockName"]+'</td>';//名称
    if (resultJSON["priceAdd"] > 0) {
        line += '<td style="color: red;font-weight: bold;">+'+resultJSON["priceAddPer"]+'↑</td>';//涨幅
        line += '<td style="color: red;font-weight: bold;">+'+resultJSON["stockPrice"]+'↑</td>';//现价
        line += '<td style="color: red;font-weight: bold;">+'+resultJSON["priceAdd"]+'↑</td>';//涨跌
    } else if (resultJSON["priceAdd"] < 0) {
        line += '<td style="color: green;font-weight: bold;">'+resultJSON["priceAddPer"]+'↓</td>';//涨幅
        line += '<td style="color: green;font-weight: bold;">'+resultJSON["stockPrice"]+'↓</td>';//现价
        line += '<td style="color: green;font-weight: bold;">'+resultJSON["priceAdd"]+'↓</td>';//涨跌
    } else {
        line += '<td style="color: gray;font-weight: bold;">'+resultJSON["priceAddPer"]+'</td>';//涨幅
        line += '<td style="color: gray;font-weight: bold;">'+resultJSON["stockPrice"]+'</td>';//现价
        line += '<td style="color: gray;font-weight: bold;">'+resultJSON["priceAdd"]+'</td>';//涨跌
    }
    return line;
}
function parseResult(result) {
    var resultJSON = {};
    resultJSON["stockCode"] = result.substring(0,result.indexOf("="));
    result = result.substring(result.indexOf("=")+1, result.length-2);
    var resultArr = result.split(",");
    resultJSON["stockName"] = resultArr[0];
    dealStockName(resultJSON["stockCode"], resultJSON["stockName"]);
    resultJSON["stockPrice"] = parseFloat(resultArr[3]).toFixed(2);
    resultJSON["yesterdatyStockPrice"] = parseFloat(resultArr[2]).toFixed(2);
    resultJSON["priceAdd"] = (parseFloat(resultArr[3])-parseFloat(resultArr[2])).toFixed(2);
    resultJSON["priceAddPer"] = ((resultJSON["priceAdd"]/parseFloat(resultArr[2]))*100).toFixed(2)+'%';
    return resultJSON;
}
function dealStockName(stockcode, stockName) {
    var stock = JSON.parse(stockCode);
    for (var index in stock) {
        if (stock[index]["stockcode"] === stockcode) {
            stock[index]["stockname"] = stockName;
        }
    }
    localStorage.stockCode = JSON.stringify(stock);
    stockCode = localStorage.stockCode;
}
var stockCode = localStorage.stockCode;
var stockList= [];
if (stockCode) {
    var stock = JSON.parse(stockCode);
    for (var index in stock) {
        stockList.push(stock[index]["stockcode"]);
    }
    initTable(stockList);
} else {
    document.getElementById('stock').innerHTML="您还未配置需要查询的股票代码";
}